# Track Titans NIT Goa — GKDC 2026

Landing page for Track Titans NIT Goa's first-ever GKDC (Go-Kart Design Challenge) participation.

## Live site
Once deployed via GitHub Pages: `https://<your-username>.github.io/track-titans-website/`

## Structure
- `index.html` — single-file site (HTML/CSS, no build step needed)

## Deploying updates
1. Edit `index.html`
2. Commit and push to `main`
3. GitHub Pages redeploys automatically within a minute or two
